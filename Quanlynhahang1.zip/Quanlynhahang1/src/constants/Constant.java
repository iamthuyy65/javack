package constants;

import java.sql.DriverManager;

public class Constant {

	// JDBC
	public static final String JDBC_URL = "jdbc:mysql://localhost:3306/restaurant";
	public static final String JDBC_USERNAME = "root";
	public static final String JDBC_PASSWORD = "1234";
}
