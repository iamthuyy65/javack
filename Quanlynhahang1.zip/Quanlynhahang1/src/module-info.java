/**
 * 
 */
/**
 * @author Admin
 *
 */
module Quanlynhahang1 {
	requires java.desktop;
	requires java.sql;
}